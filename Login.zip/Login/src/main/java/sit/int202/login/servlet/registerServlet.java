package sit.int202.login.servlet;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;

import java.io.IOException;

@WebServlet(name = "registerServlet", value = "/register")
public class registerServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        String email = request.getParameter("email");
        String user = request.getParameter("user_name");
        String pass = request.getParameter("user_password");
        if (email.length() == 0 || user.length() == 0 || pass.length() == 0) {
            request.setAttribute("message","Please Insert Your Info");
            request.getRequestDispatcher("/register.jsp").forward(request,response);
        }
        session.setAttribute("email",email);
        session.setAttribute("user_name", user);
        session.setAttribute("user_password",pass);

        request.getRequestDispatcher("login.jsp").forward(request,response);
    }
}
    