package sit.int202.login.servlet;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;

import java.io.IOException;

@WebServlet(name = "login", value = "/login")
public class loginServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String user = request.getParameter("user_name");
        String pass = request.getParameter("user_password");
        HttpSession session = request.getSession();
        String usernameSession = (String) session.getAttribute("user_name");
        String userPasswordSession = (String) session.getAttribute("user_password");
        if (user.equals(usernameSession) && pass.equals(userPasswordSession)) {
            response.sendRedirect("index.jsp");
        } else {
            response.sendRedirect("login.jsp");
        }
    }
}
    