package login.test.logintest2.servlet;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;

import java.io.IOException;

@WebServlet(name = "testCookieServlet", value = "/testCookie")
public class testCookieServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Cookie[] cookies = request.getCookies();
        for (Cookie ck : cookies) {
            if (ck.getName().equalsIgnoreCase("bgCookie")) {
                request.setAttribute("bgColor",ck.getValue());
            }
        }
        request.getRequestDispatcher("testCookie.jsp").forward(request,response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String bgColor = request.getParameter("bg");
        Cookie ck = new Cookie("bgCookie",bgColor);
        ck.setMaxAge(8*24*60*60);
        response.addCookie(ck);
        request.setAttribute("bgColor",bgColor);
        request.getRequestDispatcher("/testCookie.jsp").forward(request,response);
    }
}
    